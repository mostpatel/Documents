<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<link rel="stylesheet" href="../../../../css/jobcard2.css" />
<title> Job Card - Vaibhav Auto</title>
</head>

<body>

<div class="mainDiv">

<div class="mainTitle">
REGULAR JOB CARD PARTS AND CONSUMABLE RECORD
</div>  <!-- End of tableTitle -->

<div class="sparesUsed">

<div class="tableTitle">
SPARES USED
</div>  <!-- End of tableTitle -->

  <table border="1" width="95%">
    <tr class="headingRow">
      <td>
      Item Code
      </td>
      
      <td>
      Item Name
      </td>
      
      <td>
      Unit Price
      </td>
      
      <td>
      Qty
      </td>
      
      <td>
      Total Price
      </td>
      
      <td>
      Tax (%)
      </td>
      
       <td>
      Tax Amount
      </td>

     <td>
      Discount (%)
     </td>
     
      <td>
      Discount Amount
     </td>
      
      <td>
      Net Amount
      </td>
      
    </tr>
    
    <?php
	  for($i=0; $i<=5; $i++)
	  {
	?>
    
    <tr>
      <td>
     SWU1
      </td>
      
      <td>
     Streering Wheel Unit
      </td>
      
      <td>
     80000
      </td>
      
      <td>
    2
      </td>
      
      <td>
     160000
      </td>
      
      <td>
     VAT(10)
      </td>
      
       <td>
      16000
      </td>

     <td>
     0
     </td>
     
      <td>
      0
     </td>
      
      <td>
      176000
      </td>
      
    </tr>
    
    <?php
	  }
	?>
  </table>
  
  </div>  <!-- End of sparesUsed -->
  
  
  <div class="sparesUsed">

<div class="tableTitle">
CONSUMABLE USED
</div>  <!-- End of tableTitle -->

  <table border="1" width="95%">
    <tr class="headingRow">
      <td>
      Item Code
      </td>
      
      <td>
      Item Name
      </td>
      
      <td>
      Unit Price
      </td>
      
      <td>
      Qty
      </td>
      
      <td>
      Total Price
      </td>
      
      <td>
      Tax (%)
      </td>
      
       <td>
      Tax Amount
      </td>

     <td>
      Discount (%)
     </td>
     
      <td>
      Discount Amount
     </td>
      
      <td>
      Net Amount
      </td>
      
    </tr>
    
    <?php
	  for($i=0; $i<=5; $i++)
	  {
	?>
    
    <tr>
      <td>
     SWU1
      </td>
      
      <td>
     Streering Wheel Unit
      </td>
      
      <td>
     80000
      </td>
      
      <td>
    2
      </td>
      
      <td>
     160000
      </td>
      
      <td>
     VAT(10)
      </td>
      
       <td>
      16000
      </td>

     <td>
     0
     </td>
     
      <td>
      0
     </td>
      
      <td>
      176000
      </td>
      
    </tr>
    
    <?php
	  }
	?>
  </table>
  
  </div>  <!-- End of sparesUsed -->
  
  <div class="sparesUsed">

<div class="tableTitle">
SPARES USED IN WARRANTY
</div>  <!-- End of tableTitle -->

  <table border="1" width="95%">
    <tr class="headingRow">
      <td>
      Item Code
      </td>
      
      <td>
      Item Name
      </td>
      
      <td>
      Unit Price
      </td>
      
      <td>
      Qty
      </td>
      
      <td>
      Total Price
      </td>
      
      <td>
      Tax (%)
      </td>
      
       <td>
      Tax Amount
      </td>

     <td>
      Discount (%)
     </td>
     
      <td>
      Discount Amount
     </td>
      
      <td>
      Net Amount
      </td>
      
    </tr>
    
    <?php
	  for($i=0; $i<=5; $i++)
	  {
	?>
    
    <tr>
      <td>
     SWU1
      </td>
      
      <td>
     Streering Wheel Unit
      </td>
      
      <td>
     80000
      </td>
      
      <td>
    2
      </td>
      
      <td>
     160000
      </td>
      
      <td>
     VAT(10)
      </td>
      
       <td>
      16000
      </td>

     <td>
     100
     </td>
     
      <td>
        176000
     </td>
      
      <td>
    0
      </td>
      
    </tr>
    
    <?php
	  }
	?>
  </table>
  
  </div>  <!-- End of sparesUsed -->
  
  <div class="sparesUsed">

<div class="tableTitle">
LABOUR CHARGES
</div>  <!-- End of tableTitle -->

  <table border="1" width="95%">
    <tr class="headingRow">
      <td>
      Item Code
      </td>
      
      <td>
      Item Name
      </td>
      
      
      <td>
      Total Price
      </td>
      
      <td>
      Tax (%)
      </td>
      
       <td>
      Tax Amount
      </td>

     <td>
      Discount (%)
     </td>
     
      <td>
      Discount Amount
     </td>
      
      <td>
      Net Amount
      </td>
      
    </tr>
    
    <?php
	  for($i=0; $i<=5; $i++)
	  {
	?>
    
    <tr>
      <td>
     SWU1
      </td>
      
      <td>
     Streering Wheel Unit
      </td>
      
      
      
      <td>
     160000
      </td>
      
      <td>
     VAT(10)
      </td>
      
       <td>
      16000
      </td>

     <td>
     0
     </td>
     
      <td>
      0
     </td>
      
      <td>
      176000
      </td>
      
    </tr>
    
    <?php
	  }
	?>
  </table>
  
  </div>  <!-- End of sparesUsed -->
  
  <div class="sparesUsed">

    <div class="tableTitle">
    OUTSIDE JOB DONE
    </div>  <!-- End of tableTitle -->

  <table border="1" width="95%">
    <tr class="headingRow">
      <td>
      Item Code
      </td>
      
      <td>
      Item Name
      </td>
      
      
      
      <td>
      Total Price
      </td>
      
      <td>
      Tax (%)
      </td>
      
       <td>
      Tax Amount
      </td>

     <td>
      Discount (%)
     </td>
     
      <td>
      Discount Amount
     </td>
      
      <td>
      Net Amount
      </td>
      
    </tr>
    
    <?php
	  for($i=0; $i<=5; $i++)
	  {
	?>
    
    <tr>
      <td>
     SWU1
      </td>
      
      <td>
     Streering Wheel Unit
      </td>
      
      
      
      <td>
     160000
      </td>
      
      <td>
     VAT(10)
      </td>
      
       <td>
      16000
      </td>

     <td>
     0
     </td>
     
      <td>
      0
     </td>
      
      <td>
      176000
      </td>
      
    </tr>
    
    <?php
	  }
	?>
  </table>
  
  </div>  <!-- End of sparesUsed -->
  
  <div class="totalOfAll">
  
  <div class="tableTitle" style="border-bottom: 1px solid #000">
   FINAL CALCULATION
  </div>  <!-- End of tableTitle -->
  
    <div class="block">
     <b> Spares Used : </b> Rs.176000
    </div>   <!-- End of block -->
    
    <div class="block">
    <b> Consumable Used : </b> Rs.176000
    </div>   <!-- End of block -->
    
    <div class="block">
    <b> Labour Charges : </b> Rs.176000
    </div>   <!-- End of block -->
    
    <div class="block">
    <b> Outside Job Done : </b> Rs.176000
    </div>   <!-- End of block -->
    
    <div class="clearDiv"> </div>
    
  </div>  <!-- End of totalofAll -->
  
  <DIV class="lastDiv">
  
  <div class="date">
  Date : DD/MM/YYYY
  </div>
  
  <div class="grandtotal">
   <b> Grand Total : </b> Rs.500000
  </div>
  
  <div class="signature">
  Customer Signature : OO7
  </div>
  
  <div class="clearDiv"></div>
  
  </DIV>  <!-- End of lastDiv-->

  
</div>  <!-- End of mainDiv-->


</body>
</html>