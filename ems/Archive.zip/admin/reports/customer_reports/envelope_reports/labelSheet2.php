<?php

if(isset($_POST['selectTR']))
{
	$customer_id_array = $_POST['selectTR'];
   
	if(is_array($customer_id_array) && is_numeric($customer_id_array[0]))
	{
		
		
	}
else
exit;
}
else
exit;	 
?>

<link rel="stylesheet" href="../../../../css/labelSheet2.css" />
<div class="mainInvoiceContainer">

	<div class="row">
    	
        <div class="col1">
        </div>
        
        <div class="col2">
        </div>
                              
        <div class="col3">
        
        </div>
        
        <div style="clear:both"></div>
        
    </div>
   
   
</div>