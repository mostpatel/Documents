<div class="adminContentWrapper wrapper">

<h4 class="headingAlignment">Calulators</h4>

<div class="settingsSection">

<div class="rowOne">

     <div class="package">
     
     <a href="EmiCalc/">
     <div class="squareBox">
     
         <div class="imageHolder">
         </div>
         
     </div>
     </a>
     
     
     <div class="explanation">
     Emi Chart Calulator
     </div>
     
     </div>
     
      <div class="package">
     
     <a href="emiNormal">
     <div class="squareBox">
     
        <div class="imageHolder">
         </div>
         
     </div>
     </a>
     
     <div class="explanation">
     Instant EMI Calculator
     </div>
     
     </div>
     
     <div class="package">
     
     <a href="EMIToRate">
     <div class="squareBox">
     
        <div class="imageHolder">
         </div>
         
     </div>
     </a>
     
     <div class="explanation">
      EMI To Rate Calculator
     </div>
     
     </div>
    
     <div class="package">
     
     <a href="flatToReducing">
     <div class="squareBox">
         <div class="imageHolder">
         </div>
     </div>
     </a>
     
     <div class="explanation">
     Flat Rate To Reducing Rate
     </div>
     
     </div>
     
     <div class="package">
     
     <a href="reducingToFlat">
     <div class="squareBox">
         <div class="imageHolder">
         </div>
     </div>
     </a>
     
     <div class="explanation">
     Reducing Rate to Flat Rate
     </div>
     
     </div>
     
  </div>
     
</div>


</div> 