<?php 
require_once("cg.php");
require_once("city-functions.php");
require_once("agency-functions.php");
require_once("our-company-function.php");
require_once('EMI-functions.php');
require_once("common.php");
require_once("bd.php");
require_once("bank-functions.php");
require_once("payment-functions.php");
require_once("loan-functions.php");
require_once("installment-functions.php");


		
?>