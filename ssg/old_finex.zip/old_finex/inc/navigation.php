
            <a  href="<?php echo WEB_ROOT ?>admin/"><div class="link <?php if($selectedLink=="home") { ?> selected <?php } ?>">
            Home
           </div></a>
           
           <a  href="<?php echo WEB_ROOT ?>admin/customer"><div class="link <?php if($selectedLink=="newCustomer") { ?> selected <?php } ?>">
            Add new customer
           </div></a>
           
           <a  href="<?php echo WEB_ROOT ?>admin/search"><div class="link <?php if($selectedLink=="searchCustomer") { ?> selected <?php } ?>">
            Find customer
           </div></a>
           
           <a  href="<?php echo WEB_ROOT ?>admin/customer/EMI/index.php?view=search"><div class="link <?php if($selectedLink=="searchEMI") { ?> selected <?php } ?>">
           Find EMI details
           </div></a>
           
            <a  href="<?php echo WEB_ROOT ?>admin/customer/vehicle/insurance/index.php?view=search"><div class="link <?php if($selectedLink=="searchInsurance") { ?> selected <?php } ?>">
           Find Insurance details
           </div></a>
           
            <a  href="<?php echo WEB_ROOT ?>admin/reports/"><div class="link <?php if($selectedLink=="reports") { ?> selected <?php } ?>">
           Reports
           </div></a>
			
            <a  href="<?php echo WEB_ROOT ?>admin/calculators"><div class="link <?php if($selectedLink=="calc") { ?> selected <?php } ?>">
           Calculators
           </div></a>
           
            <a  href="<?php echo WEB_ROOT ?>admin/settings/"><div class="link <?php if($selectedLink=="settings") { ?> selected <?php } ?>">
           Settings
           </div></a>
           
           <a  href="<?php echo WEB_ROOT ?>admin/accounts/"><div class="link <?php if($selectedLink=="accounts") { ?> selected <?php } ?>">
           Accounts
           </div></a> 
           
           <div class="clearfix"></div>