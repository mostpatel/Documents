// JavaScript Document

 jQuery(".next_follow_up_date").validate({
                     expression: "if (VAL) return true; else return false;",
                    message: "Please enter  a date!"
                });
                
jQuery(".follow_up_type_id").validate({
                     expression: "if (VAL) return true; else return false;",
                    message: "Please Select Follow Up Type!"
                });
				
				

				 
				
				