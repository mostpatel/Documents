// JavaScript Document

 jQuery(".purchase_date").validate({
                     expression: "if (VAL) return true; else return false;",
                    message: "Please enter  a date!"
                });
				
				

				 
				
				