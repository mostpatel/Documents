// JavaScript Document

jQuery("#booking_date").validate({
                     expression: "if (VAL) return true; else return false;",
                    message: "Please enter  a Booking Date!"
                });
			
jQuery("#tourName").validate({
                     expression: "if (VAL) return true; else return false;",
                    message: "Please enter the Tour Name!"
                });
				
jQuery("#tourCode").validate({
                     expression: "if (VAL) return true; else return false;",
                    message: "Please enter the Tour code!"
                });
				
jQuery("#customer_name").validate
                ({
                    expression: "if (VAL) return true; else return false;",
                    message: "Please enter the Customer Name!"
                });
				
jQuery("#datepicker_tourDate").validate
                ({
                    expression: "if (VAL) return true; else return false;",
                    message: "Please enter the Tour Departure Date!"
                });
jQuery("#residence_address").validate
                ({
                    expression: "if (VAL) return true; else return false;",
                    message: "Please enter the Residence Address!"
                });
jQuery("#customerContact").validate
                ({
                    expression: "if (VAL) return true; else return false;",
                    message: "Please enter the Contact Number!"
                });

				
jQuery("#customer_name").validate
                ({
                    expression: "if (VAL) return true; else return false;",
                    message: "Please enter the Tour code!"
                });
				