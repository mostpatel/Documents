function isEnquiryTypeRefrence(value)
{
	
	if(value==3)
	{
	document.getElementById('refrenceTable').style.display="table";
	}
	
	else
	{
		
	document.getElementById('refrenceTable').style.display="none";
	
	}
	
}